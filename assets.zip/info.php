<?php
phpinfo(); 
?>